# easyrice
Easily make an image with commandoutputs
